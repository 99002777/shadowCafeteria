import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

const API_URL = 'http://localhost:8080/api/auth/';
@Injectable({
  providedIn: 'root'
})
export class CountserveService {

//   constructor(private httpClient: HttpClient) { }
//   getCount()
// {
//   return this.httpClient.get(API_URL+'count');
// }
// postRequest(jsonObj:any)
// {
//   return this.httpClient.post('http://localhost:8080/api/auth/signin',jsonObj);
// }
}
