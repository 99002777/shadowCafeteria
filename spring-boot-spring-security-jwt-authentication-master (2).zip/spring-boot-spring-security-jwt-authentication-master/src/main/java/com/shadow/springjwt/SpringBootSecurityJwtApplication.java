package com.shadow.springjwt;

import java.util.Calendar;
import java.util.TimeZone;

import org.apache.log4j.BasicConfigurator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

import com.example.SmartCafeteria1Application;
import com.example.schedular.CafeOccupancySchedular;


@SpringBootApplication(exclude = HibernateJpaAutoConfiguration.class)
public class SpringBootSecurityJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityJwtApplication.class, args);
		TimeZone tz = Calendar.getInstance().getTimeZone();
		System.out.println(tz.getID());
		BasicConfigurator.configure();
		
		SpringApplication.run(SpringBootSecurityJwtApplication.class, args);
		CafeOccupancySchedular.startInsertingPeopleCount();
		System.out.println("hiiiii");
	}

}
