package com.example.schedular;


import java.util.Properties;

import org.apache.log4j.Logger;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.config.PropertiesFactoryBean;
//import org.springframework.core.io.ClassPathResource;
//import org.springframework.scheduling.annotation.EnableScheduling;

import org.springframework.context.annotation.Bean;

public class CafeOccupancySchedular {
	
	final static Logger LOGGER = Logger.getLogger(CafeOccupancySchedular.class);

	@Bean
	public static void startInsertingPeopleCount() {
		System.out.println("startt");
		//PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
		//propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));
		//propertiesFactoryBean.afterPropertiesSet();
		//Properties prop = new Properties();
		//String runStatus = prop.getProperty("/src/main/resources/quartz.properties");
		//if (runStatus.equalsIgnoreCase("TRUE")) {
			new CafeSchedular().configureScheduler("update schedule", "VendorAppointmentTrigger",
					"vendorAppointmentGroup", "0 0/5 * 1/1 * ? *", CafeSchedularJob.class);
		//}
		System.out.println("ENDDDDDDDDDD");
	}
	
}
