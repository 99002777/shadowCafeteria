import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Historical2Component } from './historical2.component';

describe('Historical2Component', () => {
  let component: Historical2Component;
  let fixture: ComponentFixture<Historical2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Historical2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Historical2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
