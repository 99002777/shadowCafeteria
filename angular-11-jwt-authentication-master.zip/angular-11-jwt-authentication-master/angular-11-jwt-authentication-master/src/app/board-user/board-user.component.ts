import { Component, OnInit } from '@angular/core';
import { UserService } from '../_services/user.service';
import {CountserveService} from '../_services/countserve.service';
import {Observable} from 'rxjs';
@Component({
  selector: 'app-board-user',
  templateUrl: './board-user.component.html',
  styleUrls: ['./board-user.component.css']
})
export class BoardUserComponent implements OnInit {
  isDisplay=false;
  httpClientService: any;
  //user: any;
  //count1=0;
  toggleDisplay(){
    this.isDisplay= true;
  }
  content?: any;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    this.userService.getUserBoard().subscribe(
      data => {
        this.content = data;
      },
      err => {
        this.content = JSON.parse(err.error).message;
      }
    );
    //this.postCount()
   // this.count()
  }
  // count(){
  //   setTimeout(()=>{
  //     this.countService.getCount().subscribe(data1=>{
  //       this.content=data1;
  //   });
    
  
  //   },10000);
  //  // this.count1=this.httpClientService.getCount()
  //   }
  //   postCount(){
  //     let request={
  //       "username" : "divya",
       
  //       "password" : "1234567" 
  //   }
    
    
  //     this.countService.postRequest(request).subscribe(data1=>{
  //       this.user=data1;
  //       console.log("Requested.."+this.user)
  //   }
  //     );
  // }
  reloadPage(): void {
    window.location.reload();
  }
}
 

