import { TestBed } from '@angular/core/testing';

import { CountserveService } from './countserve.service';

describe('CountserveService', () => {
  let service: CountserveService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CountserveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
