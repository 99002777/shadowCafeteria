package com.shadow.springjwt.models;

public enum ERole {
	ROLE_USER,
    ROLE_ADMIN
}
