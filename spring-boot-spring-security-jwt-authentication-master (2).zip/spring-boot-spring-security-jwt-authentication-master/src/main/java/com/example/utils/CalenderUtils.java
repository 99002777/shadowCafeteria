///*package com.example.utils;
//
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//
///*public class CalenderUtils {
//	
//	//public static final String DATETIME_FORMAT4 = "yyyy-MM-dd HH:mm:ss";
//    
//	/*
//	* @Method: getTodayDateTimeRegionWise
//	* @return: values in a String
//	
//	public  String getCurrentDateTime()
//	
//	{​​​​​
//	String date = null;
//	try {​​​​​
//	DateFormat dateFormat = new SimpleDateFormat(DATETIME_FORMAT4);
//	
//	Calendar cal = Calendar.getInstance();
//	date = dateFormat.format(cal.getTime());
//	}​​​​​ catch (Exception ex) {​​​​​
//		ex.printStackTrace();
//	}​​​​​
//	return date;*/
//
//	 ​​​​​
//	
//	    
	

	


